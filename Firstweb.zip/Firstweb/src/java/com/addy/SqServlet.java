/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.addy;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADDY
 */
public class SqServlet extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
    {
//        RequestDispatcher rd= req.getRequestDispatcher("sq");
//        int output = (int)req.getAttribute("total");
        PrintWriter out = res.getWriter();
//        result=result*result;
//        out.println("Result is "+result);
        //rd.forward(req, res);
//        int result= Integer.parseInt(req.getParameter("total"));
//        System.out.println("Result is "+result);

            HttpSession session=req.getSession();
            int result= (int) session.getAttribute("total");
            result=result*result;
            out.println("Result is "+result);
            
    }
    
}

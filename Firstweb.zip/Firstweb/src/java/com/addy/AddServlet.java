/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.addy;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 
 *
 * @author ADDY
 */
public class AddServlet extends HttpServlet
{
//    public void service(HttpServletRequest req, HttpServletResponse res) throws IOException 
//            
//    {
//        int n1=Integer.parseInt(req.getParameter("num1"));
//        int n2=Integer.parseInt(req.getParameter("num2"));
//            int sum=n1+n2;
//            System.out.println("Result is"+sum); 
//        res.getWriter().println("Result is"+sum);
//            PrintWriter out= res.getWriter();
//            out.println("Result is"+sum);
//            out.println("<h1>This is the final result,/h1>");

        
        public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
        {
            int n1= Integer.parseInt(req.getParameter("num1"));
            int n2= Integer.parseInt(req.getParameter("num2"));
            int sum= n1+n2;
//            PrintWriter out= res.getWriter();
//            out.println("Result is"+sum); 
//            RequestDispatcher rd= req.getRequestDispatcher("sq");
//            req.setAttribute("total", sum);
//            rd.forward(req, res);
//            res.sendRedirect("sq");
//            res.sendRedirect("sq?total="+sum);
                    HttpSession session= req.getSession();
                    session.setAttribute("total", sum);
                    res.sendRedirect("sq");
                    
        }
        
        
}

